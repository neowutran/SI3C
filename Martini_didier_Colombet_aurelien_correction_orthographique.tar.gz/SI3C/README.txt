
=======================================================================================================================
Polytech Nice / SI3 / Module C / 2013-2014
=======================================================================================================================

Correcteur orthographique

Auteur : Martini Didier & Colombet Aurelien
Groupe : SI3 Groupe 2
Readme : Version : 1.0.0 (Dernière révision 22/01/2014 22:00)

=======================================================================================================================
Executer le programme:
=======================================================================================================================
Lancer la commande:
$ make
L'executable se trouvera dans le dossier dist/ 
Il faut lancer l'executable a partir du dossier contenant le dossier "Data/"
Exemple: ./dist/Debug/GNU-Linux-x86/si3c wword

=======================================================================================================================

Normalement le programme fonctionne correctement.
